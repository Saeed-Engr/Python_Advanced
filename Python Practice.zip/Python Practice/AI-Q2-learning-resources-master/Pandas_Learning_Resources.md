Codes Notebooks
--------------

https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/data_analysis_with_pandas_1_Series.ipynb
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/data_analysis_with_pandas_1_DataFrame.ipynb
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/data_analysis_with_pandas_2.ipynb
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/datasets.zip
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/examples.zip
(Zip files should be unzip to create subfolders. otherwise codes of pandas 2 might fail)

https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/mydata.h5
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/mydata.sqlite

https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/data_analysis_with_pandas_3.ipynb
https://github.com/aneesahmed/piaic-datascience-teaching/blob/master/data_analysis_with_pandas_4.ipynb

Just for Reading ():
https://towardsdatascience.com/data-handling-using-pandas-cleaning-and-processing-3aa657dc9418

