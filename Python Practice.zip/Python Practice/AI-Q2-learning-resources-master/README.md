https://piaic-aic.slack.com/archives/CHQ9UCUUQ/p1609919354002700


#Important Information for PIAIC AI-Q2. 
our Announcement Chanel is #announcements. ( you can not reply this channel). Please pin this channel for our future annoucement related to AI -Q2

*Our Support Channel of AI-Q2 is #ai_q2_batch4to35 
You can ask question here. 
Warning: Please avoid responding any question until you are fully aware about it. and Please behave with other students specially ladies. 
You might be blocked for any misuse or in case of any complain from any source, PIAIC management may take any legal action Please do not discuss students related thing in this channel, just ask your question and wait for the official reply. 
For students discussion there is another channel exists. which is #random Note: 

Please visit the #ai_q2_batch4to35 channel regularly (specially in late evening). and if you missed to keep it watching , please please please, scroll up and read messages before asking a question. most of the time, question has been answered but asked again and again. 
*AI-Teaching Team 
Only following people are responsible for official response/reply to your question. 
If you have still issue or concern, please direct message (DM) or "Mention" them ( by typing their name with @) and wait for their reply (Mostly teaching team reply in evening). 

(Head of AI Team) @Inam ul Haq 
(Class Teacher) @Nasir Hussain 
(Class Teacher) @A.I Teacher Qasim 
(Class Teacher) @Anees Ahmed

(Support Teacher) @Asadullah Noor 
(Support Teacher) @Wajahat Ali Naqvi 
(Support Teacher) @Mansoor Hussain 
(Support Teacher) @Umair Shehzad 
(Support Teacher) @komal aftab 
(Support Teacher) @Ramsha Azeemi

